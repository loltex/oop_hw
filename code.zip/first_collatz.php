<?php
  require 'funcs.php';

  $results = array();
  on_range_collatz($_POST["start"], $_POST["end"], $results);
  echo "Examining Collatz Conjecture in range [{$_POST["start"]}-{$_POST["end"]}]...";
  echo "<br><br>";
  $max_slices = find_max_min_iter($results)[0];
  $min_slices = find_max_min_iter($results)[1];

  echo "Numbers with min iterations:<br>";
  for ($i = 0; $i < sizeof($min_slices); $i++) {
    echo "{$min_slices[$i]["num"]} (max value: {$min_slices[$i]["max"]}, iterations: {$min_slices[$i]["iter"]}) <br>";
  }

  echo "<br>";

  echo "Numbers with max iterations:<br>";
  for ($i = 0; $i < sizeof($max_slices); $i++) {
    echo "{$max_slices[$i]["num"]} (max value: {$max_slices[$i]["max"]}, iterations: {$max_slices[$i]["iter"]}) <br>";
  }
?>
