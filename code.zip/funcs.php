<?php
  function collatz($n, &$res) {
    $begin = $max = $n;
    $iter = 0;

    while ($n != 1) {
      if ($n % 2 == 0) {
        $n /= 2;
        if ($n > $max) $max = $n;
      } elseif ($n % 2 == 1) {
        $n = (3*$n)+1;
        if ($n > $max) $max = $n;
      }
      $iter++;
    }

    array_push($res, array("num"=>$begin, "max"=>$max, "iter"=>$iter));
  }

  function on_range_collatz($start_value, $end_value, &$res) {
    for (; $start_value < $end_value; $start_value++) {
      collatz($start_value, $res);
    }
  }

  function sort_iter($a, $b) {
    if ($a["iter"] == $b["iter"]) return 0;
    return ($a["iter"] < $b["iter"]) ? -1 : 1;
  }

  function find_max_min_iter(&$res) {
    usort($res, "sort_iter");
    $max = $res[sizeof($res) - 1];
    $min = $res[0];
    $max_slices = [$max];
    $min_slices = [$min];

    // Searching for indeces with min "iter"
    for ($i = 1; $i < sizeof($res); $i++) {
      if ($min["iter"] != $res[$i]["iter"]) {
        break;
      }
      array_push($min_slices, $res[$i]);
    }
    // Searching for indeces with max "iter" ("-2" since "-1" i.e. last index is reserved by max value)
    for ($i = sizeof($res) - 2; $i > 0; $i--) {
      if ($max["iter"] != $res[$i]["iter"]) {
        break;
      }
      array_push($max_slices, $res[$i]);
    }
    return array($max_slices, $min_slices);
  }
?>
