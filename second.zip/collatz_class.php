<?php

class Collatz {
  function calculate($n) {
    $seq = array($n);
    $iter = 0;
    while ($n != 1) {
      if ($n % 2 == 0) {
        $n = $n / 2;
      } else {
        $n = $n * 3 + 1;
      }
      array_push($seq, $n);
      $iter++;
    }
    return [
      'sequence' => $seq,
      'max_value' => max($seq),
      'iterations' => $iter
    ];
  }

  function calculate_in_range($start, $end) {
    $max_iter_count = 0;
    $min_iter_count = PHP_INT_MAX;
    $max_iter_num = null;
    $min_iter_num = null;
    $max_iter_high = 0;
    $min_iter_high = PHP_INT_MAX;

    for ($i = $start; $i <= $end; $i++) {
      $collatz = new Collatz();
      $result = $collatz->calculate($i);
      if ($result['iterations'] > $max_iter_count) {
        $max_iter_count = $result['iterations'];
        $max_iter_num = $i;
        $max_iter_high = $result['max_value'];
      }
      if ($result['iterations'] < $min_iter_count) {
        $min_iter_count = $result['iterations'];
        $min_iter_num = $i;
        $min_iter_high = $result['max_value'];
      }
    }

    return [
      'max_iterations_count' => $max_iter_count,
      'max_iterations_number' => $max_iter_num,
      'max_iterations_high' => $max_iter_high,
      'min_iterations_count' => $min_iter_count,
      'min_iterations_number' => $min_iter_num,
      'min_iterations_high' => $min_iter_high
    ];
  }
  
 function arithm_progression($term, $diff, $n_terms) {
    $progression = array();
    for ($i = 0; $i < $n_terms; $i++) {
      array_push($progression, $term + $i * $diff);
    }
    return $progression;
  }
}
?>

