<?php
  require_once "collatz_class.php";

  $start = $_POST["start"];
  $end = $_POST["end"];
  $collatz_compute = new Collatz();
  $collatz_result = $collatz_compute->calculate_in_range($start, $end);

  echo "Range: $start to $end";
  echo "<br>";
  echo "Max iterations: " . $collatz_result['max_iterations_count'] . " (Number: " . $collatz_result['max_iterations_number'] . ", Max value: " . $collatz_result['max_iterations_high'] . ")\n";
  echo "<br>";
  echo "Min iterations: " . $collatz_result['min_iterations_count'] . " (Number: " . $collatz_result['min_iterations_number'] . ", Max value: " . $collatz_result['min_iterations_high'] . ")\n";
  echo "<br>";

  echo "<br>Usage of arithmetic progression:<br>";
  $progr = $collatz_compute->arithm_progression(2, 5, 13); // Base term, Difference, Number of terms
  for ($i = 0; $i < sizeof($progr); $i++) {
    echo $progr[$i];
    if (sizeof($progr) - $i > 1) {
      echo " -> ";
    }
  }
?>
